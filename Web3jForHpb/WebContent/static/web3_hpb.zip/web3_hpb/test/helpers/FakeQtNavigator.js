
var navigator = {
    qt: {
        callMhpbod: function (payload) {
            return "{}";
        }
    }
};

module.exports = navigator;

