var web3_hpb = require('web3_hpb');

console.log(web3_hpb.version.api);


